# Simulation

##Usage:

``javac *.java && java TestSimulation && gnuplot plotfile``

Pour changer les paramètres de la simulation :
 - La taille du terrain est demandé de manière interactive.
 - Les paramètres sur le comportement des cellules se changent en changeant les constantes dans les fichiers.
 - La situation de départ se modifie au niveau des fonctions `init*` de `Simulation.java`.

